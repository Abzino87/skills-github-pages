class ImageToVideoConverter {
  constructor() {
    this.imageUpload = document.getElementById('imageUpload');
    this.uploadForm = document.getElementById('uploadForm');
    this.imagePreview = document.getElementById('imagePreview');
    this.generatedVideo = document.getElementById('generatedVideo');
    this.resultSection = document.getElementById('resultSection');
    this.durationInput = document.getElementById('duration');
    this.videoDescriptionInput = document.getElementById('videoDescription');

    this.setupEventListeners();
  }

  setupEventListeners() {
    this.imageUpload.addEventListener('change', (e) => this.handleImageUpload(e));
    this.uploadForm.addEventListener('submit', (e) => this.generateVideo(e));
  }

  handleImageUpload(event) {
    const files = event.target.files;
    this.imagePreview.innerHTML = '';

    for (let file of files) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = document.createElement('img');
        img.src = e.target.result;
        this.imagePreview.appendChild(img);
      };
      reader.readAsDataURL(file);
    }
  }

  async generateVideo(event) {
    event.preventDefault();
    
    const files = this.imageUpload.files;
    const duration = this.durationInput.value;
    const description = this.videoDescriptionInput.value;

    if (files.length === 0) {
      alert('Please upload at least one image.');
      return;
    }
    
    // Show loading state
    this.resultSection.style.display = 'block';
    this.generatedVideo.style.display = 'none';
    
    try {
      // Prepare form data for API submission
      const formData = new FormData();
      for (let file of files) {
        formData.append('images', file);
      }
      formData.append('duration', duration);
      formData.append('description', description);

      // Show loading indicator
      this.generatedVideo.style.display = 'none';
      const loadingIndicator = document.createElement('p');
      loadingIndicator.textContent = 'Generating video... Please wait.';
      this.resultSection.appendChild(loadingIndicator);

      // Send request to backend API
      const response = await fetch('/generate-video', {
        method: 'POST',
        body: formData
      });

      // Remove loading indicator
      if (loadingIndicator) {
        loadingIndicator.remove();
      }

      if (!response.ok) {
        throw new Error('Video generation failed');
      }

      const responseData = await response.json();
      
      // Update video source and display
      this.generatedVideo.src = responseData.videoUrl;
      this.generatedVideo.style.display = 'block';
      this.generatedVideo.play();
    } catch (error) {
      console.error('Video generation error:', error);
      alert('Failed to generate video. Please try again.');
      this.resultSection.style.display = 'none';
    }
  }
}

// Initialize the converter when the DOM is fully loaded
document.addEventListener('DOMContentLoaded', () => {
  new ImageToVideoConverter();
});