# AI Image to Video Converter

## Setup Instructions

1. Clone the repository
2. Install dependencies: