const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const ffmpeg = require('fluent-ffmpeg');

const app = express();
const PORT = process.env.PORT || 3000;

// Configure multer for file uploads
const upload = multer({ 
  dest: 'uploads/',
  fileFilter: (req, file, cb) => {
    const allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type'));
    }
  }
});

// Serve static files
app.use(express.static('public'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Video generation endpoint
app.post('/generate-video', upload.array('images', 10), (req, res) => {
  const files = req.files;
  const duration = req.body.duration || 3;
  const description = req.body.description || '';

  if (!files || files.length === 0) {
    return res.status(400).json({ error: 'No images uploaded' });
  }

  // Ensure uploads directory exists
  const uploadsDir = path.join(__dirname, 'uploads');
  const videosDir = path.join(__dirname, 'public', 'videos');
  
  if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir);
  if (!fs.existsSync(videosDir)) fs.mkdirSync(videosDir, { recursive: true });

  // Sort files to ensure consistent order
  files.sort((a, b) => a.originalname.localeCompare(b.originalname));

  // Generate unique filename
  const outputFilename = `video-${Date.now()}.mp4`;
  const outputPath = path.join(videosDir, outputFilename);

  // Use ffmpeg to create video from images
  const command = ffmpeg();
  files.forEach(file => {
    command.input(file.path);
  });

  command
    .inputFPS(1 / Number(duration))
    .videoCodec('libx264')
    .outputOptions('-pix_fmt yuv420p')
    .output(outputPath)
    .on('end', () => {
      // Clean up uploaded image files
      files.forEach(file => {
        try {
          fs.unlinkSync(file.path);
        } catch (err) {
          console.error(`Failed to delete file ${file.path}:`, err);
        }
      });

      // Return video URL
      res.json({ 
        videoUrl: `/videos/${outputFilename}`,
        description: description
      });
    })
    .on('error', (err) => {
      console.error('Video generation error:', err);
      
      // Clean up any uploaded files
      files.forEach(file => {
        try {
          fs.unlinkSync(file.path);
        } catch (unlinkErr) {
          console.error(`Failed to delete file ${file.path}:`, unlinkErr);
        }
      });

      res.status(500).json({ error: 'Failed to generate video' });
    })
    .run();
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});